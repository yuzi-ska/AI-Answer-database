"""
OCS网课助手API测试
"""
import asyncio
import aiohttp
import json
from typing import Dict, Any


async def test_api():
    """
    测试API功能
    """
    base_url = "http://localhost:8000"
    
    # 测试问题
    test_questions = [
        {
            "question": "Python中列表和元组的区别是什么？",
            "question_type": "single",
            "options": "",
            "use_ai": True,
            "use_question_bank": True
        },
        {
            "question": "1+1等于几？",
            "question_type": "single",
            "options": "A. 1\nB. 2\nC. 3\nD. 4",
            "use_ai": True,
            "use_question_bank": False
        }
    ]
    
    async with aiohttp.ClientSession() as session:
        for i, question_data in enumerate(test_questions):
            print(f"\n测试 {i+1}: {question_data['question']}")
            
            try:
                async with session.post(
                    f"{base_url}/api/v1/answer",
                    json=question_data,
                    timeout=aiohttp.ClientTimeout(total=30)
                ) as response:
                    if response.status == 200:
                        result = await response.json()
                        print(f"  问题: {result['question']}")
                        print(f"  答案: {result['answer']}")
                        print(f"  来源: {result['source']}")
                        print(f"  置信度: {result['confidence']}")
                    else:
                        print(f"  请求失败，状态码: {response.status}")
                        response_text = await response.text()
                        print(f"  响应: {response_text}")
                        
            except asyncio.TimeoutError:
                print("  请求超时")
            except Exception as e:
                print(f"  请求出错: {e}")


async def test_health():
    """
    测试健康检查接口
    """
    base_url = "http://localhost:8000"
    
    async with aiohttp.ClientSession() as session:
        try:
            async with session.get(f"{base_url}/health") as response:
                if response.status == 200:
                    result = await response.json()
                    print(f"健康检查: {result}")
                else:
                    print(f"健康检查失败，状态码: {response.status}")
        except Exception as e:
            print(f"健康检查出错: {e}")


if __name__ == "__main__":
    print("开始测试OCS网课助手API...")
    
    # 运行健康检查
    asyncio.run(test_health())
    
    print("\nAPI测试完成！请确保API服务已启动 (uvicorn app.main:app --reload)")