"""
外部题库接口测试
"""
import asyncio
import aiohttp
import json
from typing import Dict, Any, Optional


async def test_external_api():
    """
    测试外部题库接口
    """
    # 模拟外部API响应
    mock_response = {
        "code": 1,
        "data": {
            "answers": [3, 5],
            "title": "1+2"
        },
        "msg": "成功"
    }
    
    print(f"模拟外部API响应: {mock_response}")
    
    # 模拟OCS handler处理
    handler_code = "return (res)=> res.code === 1 ? [res.data.answers[0], res.data.title] : undefined"
    safe_globals = {
        "__builtins__": {"len": len, "str": str, "int": int, "float": float, "bool": bool, "list": list, "dict": dict, "tuple": tuple},
        "res": mock_response,
        "undefined": None,
    }
    
    handler_func = eval(handler_code, safe_globals)
    result = handler_func(mock_response)
    print(f"Handler处理结果: {result}")
    
    # 测试多种响应格式
    test_cases = [
        {
            "code": 1,
            "data": {
                "answers": ["A", "B", "C"],
                "title": "测试问题"
            },
            "msg": "成功"
        },
        {
            "code": 0,
            "msg": "失败"
        },
        {
            "result": ["答案1", "问题1"]
        }
    ]
    
    for i, test_case in enumerate(test_cases):
        print(f"\n测试用例 {i+1}:")
        print(f"输入: {test_case}")
        
        safe_globals["res"] = test_case
        try:
            handler_func = eval(handler_code, safe_globals)
            result = handler_func(test_case)
            print(f"处理结果: {result}")
        except Exception as e:
            print(f"处理出错: {e}")


if __name__ == "__main__":
    asyncio.run(test_external_api())
